const request = require('supertest');
const app = require('../src/server');

describe('ONDC API Endpoints', () => {
  describe('Health Check', () => {
    test('GET /health should return 200', async () => {
      const response = await request(app)
        .get('/health')
        .expect(200);
      
      expect(response.body.success).toBe(true);
      expect(response.body.message).toContain('ONDC Network Participant API');
    });
  });

  describe('Key Generation', () => {
    test('POST /ondc/generate-keys should generate key pairs', async () => {
      const response = await request(app)
        .post('/ondc/generate-keys')
        .send({ subscriberId: 'test.example.com' })
        .expect(200);
      
      expect(response.body.success).toBe(true);
      expect(response.body.data).toHaveProperty('uniqueKeyId');
      expect(response.body.data).toHaveProperty('keyPairs');
      expect(response.body.data.keyPairs).toHaveProperty('signing');
      expect(response.body.data.keyPairs).toHaveProperty('encryption');
    });

    test('POST /ondc/generate-keys should require subscriberId', async () => {
      const response = await request(app)
        .post('/ondc/generate-keys')
        .send({})
        .expect(400);
      
      expect(response.body.success).toBe(false);
      expect(response.body.error).toContain('Subscriber ID is required');
    });
  });

  describe('Domain Verification', () => {
    test('POST /ondc/generate-verification should generate verification file', async () => {
      // First generate keys
      const keyResponse = await request(app)
        .post('/ondc/generate-keys')
        .send({ subscriberId: 'test.example.com' });
      
      const { uniqueKeyId } = keyResponse.body.data;
      
      // Then generate verification
      const response = await request(app)
        .post('/ondc/generate-verification')
        .send({ 
          subscriberId: 'test.example.com',
          uniqueKeyId 
        })
        .expect(200);
      
      expect(response.body.success).toBe(true);
      expect(response.body.data).toHaveProperty('requestId');
      expect(response.body.data).toHaveProperty('signedRequestId');
      expect(response.body.data).toHaveProperty('url');
    });

    test('GET /ondc/verification should return verification file', async () => {
      // First generate verification file
      const keyResponse = await request(app)
        .post('/ondc/generate-keys')
        .send({ subscriberId: 'test.example.com' });
      
      const { uniqueKeyId } = keyResponse.body.data;
      
      await request(app)
        .post('/ondc/generate-verification')
        .send({ 
          subscriberId: 'test.example.com',
          uniqueKeyId 
        });
      
      // Then get verification file
      const response = await request(app)
        .get('/ondc/verification')
        .expect(200);
      
      expect(response.text).toContain('ondc-site-verification');
      expect(response.text).toContain('ONDC Site Verification');
    });
  });

  describe('Registry Operations', () => {
    test('POST /ondc/lookup should handle lookup requests', async () => {
      const response = await request(app)
        .post('/ondc/lookup')
        .send({
          searchParams: {
            country: 'IND',
            domain: 'ONDC:RET10'
          },
          environment: 'staging'
        })
        .expect(200);
      
      expect(response.body).toHaveProperty('success');
    });

    test('POST /ondc/vlookup should handle vlookup requests', async () => {
      const response = await request(app)
        .post('/ondc/vlookup')
        .send({
          searchParams: {
            sender_subscriber_id: 'test.example.com',
            request_id: 'test-request-id',
            timestamp: new Date().toISOString(),
            signature: 'test-signature',
            search_parameters: {
              country: 'IND',
              domain: 'ONDC:RET10'
            }
          },
          environment: 'staging'
        })
        .expect(200);
      
      expect(response.body).toHaveProperty('success');
    });
  });

  describe('Key Management', () => {
    test('GET /ondc/keys should list key pairs', async () => {
      const response = await request(app)
        .get('/ondc/keys')
        .expect(200);
      
      expect(response.body.success).toBe(true);
      expect(response.body.data).toBeInstanceOf(Array);
    });

    test('GET /ondc/status should return system status', async () => {
      const response = await request(app)
        .get('/ondc/status')
        .expect(200);
      
      expect(response.body.success).toBe(true);
      expect(response.body.data).toHaveProperty('subscriberId');
      expect(response.body.data).toHaveProperty('verificationFileExists');
    });
  });

  describe('Error Handling', () => {
    test('should handle 404 for unknown routes', async () => {
      const response = await request(app)
        .get('/unknown-route')
        .expect(404);
      
      expect(response.body.success).toBe(false);
      expect(response.body.error).toContain('Route not found');
    });

    test('should handle validation errors', async () => {
      const response = await request(app)
        .post('/ondc/generate-keys')
        .send({ subscriberId: '' })
        .expect(400);
      
      expect(response.body.success).toBe(false);
    });
  });
});
