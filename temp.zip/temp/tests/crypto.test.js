const cryptoUtils = require('../src/utils/crypto');

describe('Crypto Utils', () => {
  describe('Key Generation', () => {
    test('should generate Ed25519 signing key pair', () => {
      const keyPair = cryptoUtils.generateSigningKeyPair();
      
      expect(keyPair).toHaveProperty('publicKey');
      expect(keyPair).toHaveProperty('privateKey');
      expect(keyPair).toHaveProperty('algorithm', 'ed25519');
      expect(keyPair.publicKey).toBeTruthy();
      expect(keyPair.privateKey).toBeTruthy();
    });

    test('should generate X25519 encryption key pair', () => {
      const keyPair = cryptoUtils.generateEncryptionKeyPair();
      
      expect(keyPair).toHaveProperty('publicKey');
      expect(keyPair).toHaveProperty('privateKey');
      expect(keyPair).toHaveProperty('algorithm', 'x25519');
      expect(keyPair.publicKey).toBeTruthy();
      expect(keyPair.privateKey).toBeTruthy();
    });
  });

  describe('Hashing', () => {
    test('should generate BLAKE-512 hash', async () => {
      const data = 'test data for hashing';
      const hash = await cryptoUtils.generateBlake512Hash(data);
      
      expect(hash).toBeTruthy();
      expect(typeof hash).toBe('string');
    });

    test('should generate consistent hash for same data', async () => {
      const data = 'consistent test data';
      const hash1 = await cryptoUtils.generateBlake512Hash(data);
      const hash2 = await cryptoUtils.generateBlake512Hash(data);
      
      expect(hash1).toBe(hash2);
    });
  });

  describe('Signing and Verification', () => {
    let keyPair;

    beforeEach(() => {
      keyPair = cryptoUtils.generateSigningKeyPair();
    });

    test('should sign data with private key', () => {
      const data = 'test data for signing';
      const signature = cryptoUtils.signData(data, keyPair.privateKey);
      
      expect(signature).toBeTruthy();
      expect(typeof signature).toBe('string');
    });

    test('should verify valid signature', () => {
      const data = 'test data for verification';
      const signature = cryptoUtils.signData(data, keyPair.privateKey);
      const isValid = cryptoUtils.verifySignature(data, signature, keyPair.publicKey);
      
      expect(isValid).toBe(true);
    });

    test('should reject invalid signature', () => {
      const data = 'test data';
      const wrongData = 'wrong data';
      const signature = cryptoUtils.signData(data, keyPair.privateKey);
      const isValid = cryptoUtils.verifySignature(wrongData, signature, keyPair.publicKey);
      
      expect(isValid).toBe(false);
    });
  });

  describe('Key Exchange', () => {
    test('should generate shared secret', () => {
      const keyPair1 = cryptoUtils.generateEncryptionKeyPair();
      const keyPair2 = cryptoUtils.generateEncryptionKeyPair();
      
      const sharedSecret1 = cryptoUtils.generateSharedSecret(
        keyPair1.privateKey,
        keyPair2.publicKey
      );
      
      const sharedSecret2 = cryptoUtils.generateSharedSecret(
        keyPair2.privateKey,
        keyPair1.publicKey
      );
      
      expect(sharedSecret1).toEqual(sharedSecret2);
      expect(sharedSecret1).toBeInstanceOf(Buffer);
    });
  });

  describe('Authorization Header', () => {
    let keyPair;

    beforeEach(() => {
      keyPair = cryptoUtils.generateSigningKeyPair();
    });

    test('should create authorization header', async () => {
      const requestBody = JSON.stringify({ test: 'data' });
      const subscriberId = 'test.example.com';
      const uniqueKeyId = 'test-key-id';
      
      const authHeader = await cryptoUtils.createAuthorizationHeader(
        requestBody,
        subscriberId,
        uniqueKeyId,
        keyPair.privateKey
      );
      
      expect(authHeader).toContain('Signature');
      expect(authHeader).toContain(subscriberId);
      expect(authHeader).toContain(uniqueKeyId);
      expect(authHeader).toContain('ed25519');
    });
  });

  describe('ID Generation', () => {
    test('should generate unique request ID', () => {
      const requestId = cryptoUtils.generateRequestId();
      
      expect(requestId).toBeTruthy();
      expect(typeof requestId).toBe('string');
      expect(requestId.length).toBeGreaterThan(0);
    });

    test('should generate unique key ID', () => {
      const keyId = cryptoUtils.generateUniqueKeyId();
      
      expect(keyId).toBeTruthy();
      expect(typeof keyId).toBe('string');
      expect(keyId.length).toBeGreaterThan(0);
    });
  });
});
