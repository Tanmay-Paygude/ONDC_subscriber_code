const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const logger = require('../utils/logger');
const config = require('../config/environment');

/**
 * Security middleware configuration
 */
const securityMiddleware = {
  /**
   * Helmet security headers
   */
  helmet: helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'"],
        scriptSrc: ["'self'"],
        imgSrc: ["'self'", "data:", "https:"],
        connectSrc: ["'self'"],
        fontSrc: ["'self'"],
        objectSrc: ["'none'"],
        mediaSrc: ["'self'"],
        frameSrc: ["'none'"],
      },
    },
    crossOriginEmbedderPolicy: false,
    hsts: {
      maxAge: 31536000,
      includeSubDomains: true,
      preload: true
    }
  }),

  /**
   * Rate limiting middleware
   */
  rateLimit: rateLimit({
    windowMs: config.rateLimit.windowMs,
    max: config.rateLimit.maxRequests,
    message: {
      success: false,
      error: 'Too many requests from this IP, please try again later.',
      retryAfter: Math.ceil(config.rateLimit.windowMs / 1000)
    },
    standardHeaders: true,
    legacyHeaders: false,
    handler: (req, res) => {
      logger.warn(`Rate limit exceeded for IP: ${req.ip}`);
      res.status(429).json({
        success: false,
        error: 'Too many requests from this IP, please try again later.',
        retryAfter: Math.ceil(config.rateLimit.windowMs / 1000)
      });
    }
  }),

  /**
   * CORS configuration
   */
  cors: (req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization, X-Environment');
    
    if (req.method === 'OPTIONS') {
      res.sendStatus(200);
    } else {
      next();
    }
  },

  /**
   * Request logging middleware
   */
  requestLogger: (req, res, next) => {
    const start = Date.now();
    
    res.on('finish', () => {
      const duration = Date.now() - start;
      logger.info(`${req.method} ${req.path} - ${res.statusCode} - ${duration}ms - ${req.ip}`);
    });
    
    next();
  },

  /**
   * Error handling middleware
   */
  errorHandler: (err, req, res, next) => {
    logger.error(`Error: ${err.message}`, {
      stack: err.stack,
      url: req.url,
      method: req.method,
      ip: req.ip
    });

    // Don't leak error details in production
    const isDevelopment = config.nodeEnv === 'development';
    
    res.status(err.status || 500).json({
      success: false,
      error: isDevelopment ? err.message : 'Internal server error',
      ...(isDevelopment && { stack: err.stack })
    });
  },

  /**
   * 404 handler
   */
  notFound: (req, res) => {
    res.status(404).json({
      success: false,
      error: 'Route not found',
      path: req.path,
      method: req.method
    });
  },

  /**
   * Body size limiter
   */
  bodySizeLimit: (req, res, next) => {
    const contentLength = parseInt(req.headers['content-length'] || '0');
    const maxSize = 10 * 1024 * 1024; // 10MB

    if (contentLength > maxSize) {
      return res.status(413).json({
        success: false,
        error: 'Request entity too large',
        maxSize: '10MB'
      });
    }

    next();
  },

  /**
   * IP whitelist middleware (optional)
   */
  ipWhitelist: (allowedIPs = []) => {
    return (req, res, next) => {
      if (allowedIPs.length === 0) {
        return next();
      }

      const clientIP = req.ip || req.connection.remoteAddress;
      
      if (!allowedIPs.includes(clientIP)) {
        logger.warn(`Unauthorized IP access attempt: ${clientIP}`);
        return res.status(403).json({
          success: false,
          error: 'Access denied from this IP address'
        });
      }

      next();
    };
  },

  /**
   * Request timeout middleware
   */
  timeout: (timeoutMs = 30000) => {
    return (req, res, next) => {
      req.setTimeout(timeoutMs, () => {
        logger.warn(`Request timeout: ${req.url}`);
        res.status(408).json({
          success: false,
          error: 'Request timeout'
        });
      });

      next();
    };
  },

  /**
   * Security headers for ONDC specific endpoints
   */
  ondcSecurity: (req, res, next) => {
    // Add specific headers for ONDC endpoints
    res.header('X-Content-Type-Options', 'nosniff');
    res.header('X-Frame-Options', 'DENY');
    res.header('X-XSS-Protection', '1; mode=block');
    res.header('Referrer-Policy', 'strict-origin-when-cross-origin');
    
    next();
  }
};

module.exports = securityMiddleware;
