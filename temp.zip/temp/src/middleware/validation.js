const Joi = require('joi');
const logger = require('../utils/logger');

/**
 * Validation middleware factory
 * @param {Object} schema - Joi schema
 * @param {string} property - Request property to validate (body, query, params)
 * @returns {Function} Express middleware
 */
const validate = (schema, property = 'body') => {
  return (req, res, next) => {
    // Debug logging
    logger.info(`Validating ${property}:`, JSON.stringify(req[property]));
    
    const { error, value } = schema.validate(req[property], { abortEarly: false });
    
    if (error) {
      const errorDetails = error.details.map(detail => ({
        field: detail.path.join('.'),
        message: detail.message,
        value: detail.context?.value
      }));

      logger.warn(`Validation error: ${JSON.stringify(errorDetails)}`);
      
      return res.status(400).json({
        success: false,
        error: 'Validation failed',
        details: errorDetails
      });
    }

    req[property] = value;
    next();
  };
};

// Common schemas
const schemas = {
  // Key generation schema
  generateKeys: Joi.object({
    subscriberId: Joi.string().required().min(1).max(255)
  }),

  // Verification generation schema
  generateVerification: Joi.object({
    subscriberId: Joi.string().required().min(1).max(255),
    uniqueKeyId: Joi.string().required().min(1).max(255)
  }),

  // Subscription schema
  subscribe: Joi.object({
    opsNo: Joi.number().integer().min(1).max(5).required(),
    subscriberId: Joi.string().required().min(1).max(255),
    uniqueKeyId: Joi.string().required().min(1).max(255),
    environment: Joi.string().valid('staging', 'preprod', 'prod').default('staging'),
    entityData: Joi.object({
      legalEntityName: Joi.string().required().min(1).max(255),
      businessAddress: Joi.string().required().min(1).max(500),
      cityCodes: Joi.array().items(Joi.string()).default(['std:080']),
      gstNo: Joi.string().required().min(1).max(50),
      panName: Joi.string().required().min(1).max(255),
      panNo: Joi.string().required().min(1).max(50),
      dateOfIncorporation: Joi.string().required().min(1).max(50),
      authorisedSignatoryName: Joi.string().required().min(1).max(255),
      authorisedSignatoryAddress: Joi.string().required().min(1).max(500),
      emailId: Joi.string().email().required(),
      mobileNo: Joi.string().required().min(10).max(15),
      country: Joi.string().default('IND')
    }).required(),
    networkParticipants: Joi.array().items(
      Joi.object({
        type: Joi.string().valid('buyerApp', 'sellerApp').required(),
        msn: Joi.boolean().default(false),
        cityCodes: Joi.array().items(Joi.string()).default(['std:080']),
        subscriberUrl: Joi.string().default('/'),
        domain: Joi.string().default('nic2004:52110'),
        sellerOnRecord: Joi.object({
          uniqueKeyId: Joi.string().required(),
          keyPair: Joi.object({
            signingPublicKey: Joi.string().required(),
            encryptionPublicKey: Joi.string().required(),
            validFrom: Joi.string().required(),
            validUntil: Joi.string().required()
          }).required(),
          cityCodes: Joi.array().items(Joi.string()).default(['std:080'])
        }).when('type', {
          is: 'sellerApp',
          then: Joi.when('msn', {
            is: true,
            then: Joi.required(),
            otherwise: Joi.forbidden()
          })
        })
      })
    ).min(1).required()
  }),

  // OnSubscribe callback schema
  onSubscribe: Joi.object({
    subscriber_id: Joi.string().required().min(1).max(255),
    challenge: Joi.string().required().min(1)
  }),

  // Lookup schema
  lookup: Joi.object({
    searchParams: Joi.object({
      country: Joi.string().required().min(2).max(3),
      domain: Joi.string().required().min(1).max(100),
      type: Joi.string().valid('buyerApp', 'sellerApp', 'gateway').optional(),
      city: Joi.string().optional(),
      subscriber_id: Joi.string().optional()
    }).required(),
    environment: Joi.string().valid('staging', 'preprod', 'prod').default('staging')
  }),

  // VLookup schema
  vlookup: Joi.object({
    searchParams: Joi.object({
      sender_subscriber_id: Joi.string().required().min(1).max(255),
      request_id: Joi.string().required().min(1).max(255),
      timestamp: Joi.string().required().min(1).max(50),
      signature: Joi.string().required().min(1).max(500),
      search_parameters: Joi.object({
        country: Joi.string().required().min(2).max(3),
        domain: Joi.string().required().min(1).max(100),
        type: Joi.string().valid('buyerApp', 'sellerApp', 'gateway').optional(),
        city: Joi.string().optional(),
        subscriber_id: Joi.string().optional()
      }).required()
    }).required(),
    environment: Joi.string().valid('staging', 'preprod', 'prod').default('staging')
  }),

  // Key parameters schema
  keyParams: Joi.object({
    subscriberId: Joi.string().required().min(1).max(255),
    uniqueKeyId: Joi.string().required().min(1).max(255)
  })
};

// Validation middleware functions
const validationMiddleware = {
  validate: validate,
  schemas: schemas,
  validateGenerateKeys: validate(schemas.generateKeys),
  validateGenerateVerification: validate(schemas.generateVerification),
  validateSubscribe: validate(schemas.subscribe),
  validateOnSubscribe: validate(schemas.onSubscribe),
  validateLookup: validate(schemas.lookup),
  validateVlookup: validate(schemas.vlookup),
  validateKeyParams: validate(schemas.keyParams, 'params')
};

module.exports = validationMiddleware;
