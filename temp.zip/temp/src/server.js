const express = require('express');
const path = require('path');
const config = require('./config/environment');
const logger = require('./utils/logger');
const securityMiddleware = require('./middleware/security');
const ondcRoutes = require('./routes/ondc');

// Create Express app
const app = express();

// Body parsing middleware (must be before other middleware)
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Debug middleware to check body parsing
app.use((req, res, next) => {
  if (req.method === 'POST' && req.path.includes('/ondc/')) {
    console.log('DEBUG - Request method:', req.method);
    console.log('DEBUG - Request path:', req.path);
    console.log('DEBUG - Content-Type:', req.headers['content-type']);
    console.log('DEBUG - Body:', JSON.stringify(req.body));
  }
  next();
});

// Simple test endpoint
app.post('/test-simple', (req, res) => {
  console.log('SIMPLE TEST - Body:', JSON.stringify(req.body));
  console.log('SIMPLE TEST - Headers:', JSON.stringify(req.headers));
  res.json({
    success: true,
    received: req.body,
    headers: req.headers
  });
});

// Even simpler test
app.post('/test-raw', (req, res) => {
  let body = '';
  req.on('data', chunk => {
    body += chunk.toString();
  });
  req.on('end', () => {
    console.log('RAW TEST - Raw body:', body);
    res.json({
      success: true,
      rawBody: body
    });
  });
});

// Security middleware
// app.use(securityMiddleware.helmet); // Temporarily disabled for debugging
// app.use(securityMiddleware.cors); // Temporarily disabled for debugging
app.use(securityMiddleware.requestLogger);
// app.use(securityMiddleware.bodySizeLimit); // Temporarily disabled for debugging
app.use(securityMiddleware.timeout(30000));

// Static files for domain verification
app.use(express.static(path.join(__dirname, '../public')));

// Serve verification file directly
app.get('/ondc-site-verification.html', async (req, res) => {
  try {
    const domainVerification = require('./services/domainVerification');
    const htmlContent = await domainVerification.getVerificationFileContent();
    res.setHeader('Content-Type', 'text/html');
    res.send(htmlContent);
  } catch (error) {
    res.status(404).json({
      success: false,
      error: 'Verification file not found'
    });
  }
});


// ONDC specific security headers
// app.use('/ondc', securityMiddleware.ondcSecurity); // Temporarily disabled for debugging

// Rate limiting
app.use(securityMiddleware.rateLimit);

// Routes
app.use('/ondc', ondcRoutes);

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({
    success: true,
    message: 'ONDC Network Participant API is running',
    timestamp: new Date().toISOString(),
    environment: config.nodeEnv,
    version: '1.0.0'
  });
});

// Root endpoint
app.get('/', (req, res) => {
  res.json({
    success: true,
    message: 'ONDC Network Participant API',
    version: '1.0.0',
    endpoints: {
      health: '/health',
      ondc: '/ondc',
      documentation: 'https://github.com/your-repo/ondc-network-participant'
    }
  });
});

// Error handling middleware
app.use(securityMiddleware.notFound);
app.use(securityMiddleware.errorHandler);

// Start server
const PORT = config.port;
const server = app.listen(PORT, () => {
  logger.info(`ONDC Network Participant API server started on port ${PORT}`);
  logger.info(`Environment: ${config.nodeEnv}`);
  logger.info(`Health check: http://localhost:${PORT}/health`);
  logger.info(`ONDC endpoints: http://localhost:${PORT}/ondc`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  logger.info('SIGTERM received, shutting down gracefully');
  server.close(() => {
    logger.info('Process terminated');
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  logger.info('SIGINT received, shutting down gracefully');
  server.close(() => {
    logger.info('Process terminated');
    process.exit(0);
  });
});

// Handle uncaught exceptions
process.on('uncaughtException', (error) => {
  logger.error('Uncaught Exception:', error);
  process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
  logger.error('Unhandled Rejection at:', promise, 'reason:', reason);
  process.exit(1);
});

module.exports = app;
