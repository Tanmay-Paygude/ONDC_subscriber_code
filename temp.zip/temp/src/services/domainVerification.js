const cryptoUtils = require('../utils/crypto');
const logger = require('../utils/logger');
const fs = require('fs').promises;
const path = require('path');

class DomainVerification {
  constructor() {
    this.publicPath = path.join(__dirname, '../../public');
    this.ensurePublicDirectory();
  }

  /**
   * Ensure public directory exists
   */
  async ensurePublicDirectory() {
    try {
      await fs.access(this.publicPath);
    } catch (error) {
      await fs.mkdir(this.publicPath, { recursive: true });
      logger.info('Created public directory');
    }
  }

  /**
   * Generate domain verification file
   * @param {string} subscriberId - Subscriber ID
   * @param {string} privateKeyBase64 - Private key for signing
   * @returns {Object} Verification file details
   */
  async generateVerificationFile(subscriberId, privateKeyBase64) {
    try {
      logger.info(`Generating domain verification file for: ${subscriberId}`);

      // Generate unique request ID
      const requestId = cryptoUtils.generateRequestId();
      
      // Sign the request ID using Ed25519 without hashing
      const signedRequestId = cryptoUtils.signData(requestId, privateKeyBase64);
      
      // Create verification HTML content
      const htmlContent = this.createVerificationHtml(signedRequestId);
      
      // Save verification file
      const filePath = path.join(this.publicPath, 'ondc-site-verification.html');
      await fs.writeFile(filePath, htmlContent, 'utf8');
      
      logger.info(`Domain verification file created: ${filePath}`);
      
      return {
        requestId,
        signedRequestId,
        filePath,
        url: `https://${subscriberId}/ondc-site-verification.html`,
        htmlContent
      };

    } catch (error) {
      logger.error(`Failed to generate verification file: ${error.message}`);
      throw error;
    }
  }

  /**
   * Create verification HTML content
   * @param {string} signedRequestId - Signed request ID
   * @returns {string} HTML content
   */
  createVerificationHtml(signedRequestId) {
    return `<!DOCTYPE html>
<html>
    <head>
        <meta name='ondc-site-verification' content='${signedRequestId}' />
        <title>ONDC Site Verification</title>
    </head>
    <body>
        <h1>ONDC Site Verification Page</h1>
        <p>This page is used for domain ownership verification by ONDC Network Registry.</p>
        <p>Verification ID: ${signedRequestId}</p>
        <p>Generated at: ${new Date().toISOString()}</p>
    </body>
</html>`;
  }

  /**
   * Verify domain ownership
   * @param {string} subscriberId - Subscriber ID
   * @param {string} publicKeyBase64 - Public key for verification
   * @returns {Object} Verification result
   */
  async verifyDomainOwnership(subscriberId, publicKeyBase64) {
    try {
      logger.info(`Verifying domain ownership for: ${subscriberId}`);

      // Read verification file
      const filePath = path.join(this.publicPath, 'ondc-site-verification.html');
      const htmlContent = await fs.readFile(filePath, 'utf8');
      
      // Extract signed request ID from HTML
      const signedRequestId = this.extractSignedRequestId(htmlContent);
      
      if (!signedRequestId) {
        throw new Error('Signed request ID not found in verification file');
      }

      // Extract request ID from the signature (this is a simplified approach)
      // In real implementation, you would need to store the original request ID
      const requestId = await this.extractRequestIdFromSignature(signedRequestId, publicKeyBase64);
      
      if (!requestId) {
        throw new Error('Failed to extract request ID from signature');
      }

      logger.info(`Domain ownership verified for: ${subscriberId}`);
      
      return {
        isValid: true,
        subscriberId,
        requestId,
        signedRequestId,
        verifiedAt: new Date().toISOString()
      };

    } catch (error) {
      logger.error(`Domain ownership verification failed: ${error.message}`);
      return {
        isValid: false,
        error: error.message,
        subscriberId
      };
    }
  }

  /**
   * Extract signed request ID from HTML content
   * @param {string} htmlContent - HTML content
   * @returns {string} Signed request ID
   */
  extractSignedRequestId(htmlContent) {
    const match = htmlContent.match(/content='([^']+)'/);
    return match ? match[1] : null;
  }

  /**
   * Extract request ID from signature (simplified approach)
   * @param {string} signedRequestId - Signed request ID
   * @param {string} publicKeyBase64 - Public key
   * @returns {string} Original request ID
   */
  async extractRequestIdFromSignature(signedRequestId, publicKeyBase64) {
    try {
      // This is a simplified approach
      // In a real implementation, you would need to store the original request ID
      // and verify the signature against it
      
      // For now, we'll return a placeholder
      // In production, you should store the request ID when generating the signature
      return 'extracted-request-id';
    } catch (error) {
      logger.error(`Failed to extract request ID: ${error.message}`);
      return null;
    }
  }

  /**
   * Check if verification file exists
   * @param {string} subscriberId - Subscriber ID
   * @returns {boolean} True if file exists
   */
  async verificationFileExists(subscriberId) {
    try {
      const filePath = path.join(this.publicPath, 'ondc-site-verification.html');
      await fs.access(filePath);
      return true;
    } catch (error) {
      return false;
    }
  }

  /**
   * Get verification file content
   * @returns {string} HTML content
   */
  async getVerificationFileContent() {
    try {
      const filePath = path.join(this.publicPath, 'ondc-site-verification.html');
      return await fs.readFile(filePath, 'utf8');
    } catch (error) {
      logger.error(`Failed to read verification file: ${error.message}`);
      throw error;
    }
  }

  /**
   * Delete verification file
   */
  async deleteVerificationFile() {
    try {
      const filePath = path.join(this.publicPath, 'ondc-site-verification.html');
      await fs.unlink(filePath);
      logger.info('Domain verification file deleted');
    } catch (error) {
      logger.error(`Failed to delete verification file: ${error.message}`);
      throw error;
    }
  }

  /**
   * Validate verification file format
   * @param {string} htmlContent - HTML content
   * @returns {Object} Validation result
   */
  validateVerificationFile(htmlContent) {
    const errors = [];

    try {
      // Check for required meta tag
      if (!htmlContent.includes('ondc-site-verification')) {
        errors.push('Missing ondc-site-verification meta tag');
      }

      // Check for content attribute
      const contentMatch = htmlContent.match(/content='([^']+)'/);
      if (!contentMatch) {
        errors.push('Missing content attribute in meta tag');
      }

      // Check for valid HTML structure
      if (!htmlContent.includes('<html>') || !htmlContent.includes('</html>')) {
        errors.push('Invalid HTML structure');
      }

      return {
        isValid: errors.length === 0,
        errors
      };

    } catch (error) {
      return {
        isValid: false,
        errors: [`Validation error: ${error.message}`]
      };
    }
  }
}

module.exports = new DomainVerification();
