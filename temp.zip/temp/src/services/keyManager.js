const cryptoUtils = require('../utils/crypto');
const logger = require('../utils/logger');
const fs = require('fs').promises;
const path = require('path');

class KeyManager {
  constructor() {
    this.keysPath = path.join(__dirname, '../../keys');
    this.ensureKeysDirectory();
  }

  /**
   * Ensure keys directory exists
   */
  async ensureKeysDirectory() {
    try {
      await fs.access(this.keysPath);
    } catch (error) {
      await fs.mkdir(this.keysPath, { recursive: true });
      logger.info('Created keys directory');
    }
  }

  /**
   * Generate and save key pairs for ONDC registration
   * @param {string} subscriberId - Subscriber ID
   * @param {string} uniqueKeyId - Unique key ID
   * @returns {Object} Generated key pairs
   */
  async generateKeyPairs(subscriberId, uniqueKeyId) {
    try {
      logger.info(`Generating key pairs for subscriber: ${subscriberId}`);

      // Generate signing key pair (Ed25519)
      const signingKeys = cryptoUtils.generateSigningKeyPair();
      
      // Generate encryption key pair (X25519)
      const encryptionKeys = cryptoUtils.generateEncryptionKeyPair();

      const keyPairs = {
        signing: {
          publicKey: signingKeys.publicKey,
          privateKey: signingKeys.privateKey,
          algorithm: signingKeys.algorithm
        },
        encryption: {
          publicKey: encryptionKeys.publicKey,
          privateKey: encryptionKeys.privateKey,
          algorithm: encryptionKeys.algorithm
        },
        metadata: {
          subscriberId,
          uniqueKeyId,
          generatedAt: new Date().toISOString(),
          validFrom: new Date().toISOString(),
          validUntil: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString() // 1 year
        }
      };

      // Save keys to file
      await this.saveKeyPairs(subscriberId, uniqueKeyId, keyPairs);

      logger.info(`Successfully generated key pairs for subscriber: ${subscriberId}`);
      return keyPairs;

    } catch (error) {
      logger.error(`Failed to generate key pairs: ${error.message}`);
      throw error;
    }
  }

  /**
   * Save key pairs to file
   * @param {string} subscriberId - Subscriber ID
   * @param {string} uniqueKeyId - Unique key ID
   * @param {Object} keyPairs - Key pairs to save
   */
  async saveKeyPairs(subscriberId, uniqueKeyId, keyPairs) {
    try {
      const fileName = `${subscriberId.replace(/[^a-zA-Z0-9.-]/g, '_')}_${uniqueKeyId}.json`;
      const filePath = path.join(this.keysPath, fileName);
      
      await fs.writeFile(filePath, JSON.stringify(keyPairs, null, 2));
      logger.info(`Saved key pairs to: ${filePath}`);
    } catch (error) {
      logger.error(`Failed to save key pairs: ${error.message}`);
      throw error;
    }
  }

  /**
   * Load key pairs from file
   * @param {string} subscriberId - Subscriber ID
   * @param {string} uniqueKeyId - Unique key ID
   * @returns {Object} Loaded key pairs
   */
  async loadKeyPairs(subscriberId, uniqueKeyId) {
    try {
      const fileName = `${subscriberId.replace(/[^a-zA-Z0-9.-]/g, '_')}_${uniqueKeyId}.json`;
      const filePath = path.join(this.keysPath, fileName);
      
      // Check if file exists
      try {
        await fs.access(filePath);
      } catch (accessError) {
        throw new Error(`Key pair not found for subscriber: ${subscriberId}, uniqueKeyId: ${uniqueKeyId}. Please generate keys first.`);
      }
      
      const data = await fs.readFile(filePath, 'utf8');
      const keyPairs = JSON.parse(data);
      
      logger.info(`Loaded key pairs for subscriber: ${subscriberId}`);
      return keyPairs;
    } catch (error) {
      logger.error(`Failed to load key pairs: ${error.message}`);
      throw error;
    }
  }

  /**
   * List all available key pairs
   * @returns {Array} List of key pair files
   */
  async listKeyPairs() {
    try {
      const files = await fs.readdir(this.keysPath);
      const keyFiles = files.filter(file => file.endsWith('.json'));
      
      const keyPairs = [];
      for (const file of keyFiles) {
        try {
          const filePath = path.join(this.keysPath, file);
          const data = await fs.readFile(filePath, 'utf8');
          const keyPair = JSON.parse(data);
          keyPairs.push({
            fileName: file,
            subscriberId: keyPair.metadata.subscriberId,
            uniqueKeyId: keyPair.metadata.uniqueKeyId,
            generatedAt: keyPair.metadata.generatedAt,
            validUntil: keyPair.metadata.validUntil
          });
        } catch (error) {
          logger.warn(`Failed to parse key file: ${file}`);
        }
      }
      
      return keyPairs;
    } catch (error) {
      logger.error(`Failed to list key pairs: ${error.message}`);
      throw error;
    }
  }

  /**
   * Delete key pairs
   * @param {string} subscriberId - Subscriber ID
   * @param {string} uniqueKeyId - Unique key ID
   */
  async deleteKeyPairs(subscriberId, uniqueKeyId) {
    try {
      const fileName = `${subscriberId.replace(/[^a-zA-Z0-9.-]/g, '_')}_${uniqueKeyId}.json`;
      const filePath = path.join(this.keysPath, fileName);
      
      // Check if file exists before deleting
      try {
        await fs.access(filePath);
      } catch (accessError) {
        throw new Error(`Key pair not found for subscriber: ${subscriberId}, uniqueKeyId: ${uniqueKeyId}. Nothing to delete.`);
      }
      
      await fs.unlink(filePath);
      logger.info(`Deleted key pairs for subscriber: ${subscriberId}`);
    } catch (error) {
      logger.error(`Failed to delete key pairs: ${error.message}`);
      throw error;
    }
  }

  /**
   * Validate key pairs
   * @param {Object} keyPairs - Key pairs to validate
   * @returns {Object} Validation result
   */
  validateKeyPairs(keyPairs) {
    const errors = [];

    try {
      // Validate signing keys
      if (!keyPairs.signing || !keyPairs.signing.publicKey || !keyPairs.signing.privateKey) {
        errors.push('Signing keys are missing or invalid');
      }

      // Validate encryption keys
      if (!keyPairs.encryption || !keyPairs.encryption.publicKey || !keyPairs.encryption.privateKey) {
        errors.push('Encryption keys are missing or invalid');
      }

      // Test signature generation and verification
      if (keyPairs.signing && keyPairs.signing.publicKey && keyPairs.signing.privateKey) {
        try {
          const testData = 'test data for validation';
          const signature = cryptoUtils.signData(testData, keyPairs.signing.privateKey);
          const isValid = cryptoUtils.verifySignature(testData, signature, keyPairs.signing.publicKey);
          
          if (!isValid) {
            errors.push('Signing key validation failed');
          }
        } catch (error) {
          errors.push(`Signing key validation error: ${error.message}`);
        }
      }

      return {
        isValid: errors.length === 0,
        errors
      };

    } catch (error) {
      return {
        isValid: false,
        errors: [`Validation error: ${error.message}`]
      };
    }
  }

  /**
   * Get key pairs for ONDC registration
   * @param {string} subscriberId - Subscriber ID
   * @param {string} uniqueKeyId - Unique key ID
   * @returns {Object} Formatted key pairs for ONDC API
   */
  async getKeyPairsForRegistration(subscriberId, uniqueKeyId) {
    try {
      const keyPairs = await this.loadKeyPairs(subscriberId, uniqueKeyId);
      
      return {
        signing_public_key: keyPairs.signing.publicKey,
        encryption_public_key: keyPairs.encryption.publicKey,
        valid_from: keyPairs.metadata.validFrom,
        valid_until: keyPairs.metadata.validUntil
      };
    } catch (error) {
      logger.error(`Failed to get key pairs for registration: ${error.message}`);
      throw error;
    }
  }
}

module.exports = new KeyManager();
