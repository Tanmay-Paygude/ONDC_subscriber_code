require('dotenv').config();

const config = {
  // Server Configuration
  port: process.env.PORT || 3000,
  nodeEnv: process.env.NODE_ENV || 'development',
  
  // ONDC Registry URLs
  registry: {
    staging: process.env.STAGING_REGISTRY_URL || 'https://staging.registry.ondc.org/subscribe',
    preprod: process.env.PREPROD_REGISTRY_URL || 'https://preprod.registry.ondc.org/ondc/subscribe',
    prod: process.env.PROD_REGISTRY_URL || 'https://prod.registry.ondc.org/subscribe'
  },
  
  // ONDC Public Keys for Challenge Decryption
  ondcPublicKeys: {
    staging: process.env.ONDC_PUBLIC_KEY_STAGING || 'MCowBQYDK2VuAyEAduMuZgmtpjdCuxv+Nc49K0cB6tL/Dj3HZetvVN7ZekM=',
    preprod: process.env.ONDC_PUBLIC_KEY_PREPROD || 'MCowBQYDK2VuAyEAa9Wbpvd9SsrpOZFcynyt/TO3x0Yrqyys4NUGIvyxX2Q=',
    prod: process.env.ONDC_PUBLIC_KEY_PROD || 'MCowBQYDK2VuAyEAvVEyZY91O2yV8w8/CAwVDAnqIZDJJUPdLUUKwLo3K0M='
  },
  
  // Network Participant Configuration
  subscriber: {
    id: process.env.SUBSCRIBER_ID || 'tsp-seller.ondc.docboyz.in',
    callbackUrl: process.env.CALLBACK_URL || '/ondc/callback',
    subscriberUrl: process.env.SUBSCRIBER_URL || '/'
  },
  
  // SSL Configuration
  ssl: {
    certPath: process.env.SSL_CERT_PATH || './certs/cert.pem',
    keyPath: process.env.SSL_KEY_PATH || './certs/private.key'
  },
  
  // Logging Configuration
  logging: {
    level: process.env.LOG_LEVEL || 'info',
    file: process.env.LOG_FILE || './logs/ondc.log'
  },
  
  // Rate Limiting
  rateLimit: {
    windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000, // 15 minutes
    maxRequests: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS) || 100
  }
};

module.exports = config;
