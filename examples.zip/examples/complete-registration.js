/**
 * Complete ONDC Network Participant Registration Example
 * 
 * This example demonstrates the complete flow for registering
 * a Network Participant with ONDC registry.
 */

const axios = require('axios');
const cryptoUtils = require('../src/utils/crypto');
const keyManager = require('../src/services/keyManager');
const domainVerification = require('../src/services/domainVerification');
const registryService = require('../src/services/registryService');

// Configuration
const config = {
  subscriberId: 'tsp-seller.ondc.docboyz.in',
  environment: 'staging', // staging, preprod, prod
  entityData: {
    legalEntityName: 'Novacred Private Limited',
    businessAddress: 'Your Business Address, City, State, PIN',
    cityCodes: ['std:080'], // Bangalore
    gstNo: '27AAACN2082N1Z8',
    panName: 'Novacred Private Limited',
    panNo: 'AALCM8972B',
    dateOfIncorporation: '01/01/2020',
    authorisedSignatoryName: 'Authorised Signatory Name',
    authorisedSignatoryAddress: 'Signatory Address',
    emailId: 'onenovacred@gmail.com',
    mobileNo: '9876543210',
    country: 'IND'
  },
  networkParticipants: [
    {
      type: 'sellerApp',
      msn: false,
      cityCodes: ['std:080'],
      subscriberUrl: '/',
      domain: 'nic2004:60232'  // Logistics domain as per whitelisting
    }
  ]
};

async function completeRegistration() {
  try {
    console.log('🚀 Starting ONDC Network Participant Registration...\n');

    // Step 1: Generate Key Pairs
    console.log('📝 Step 1: Generating key pairs...');
    const uniqueKeyId = cryptoUtils.generateUniqueKeyId();
    const keyPairs = await keyManager.generateKeyPairs(config.subscriberId, uniqueKeyId);
    console.log('✅ Key pairs generated successfully');
    console.log(`   Unique Key ID: ${uniqueKeyId}`);
    console.log(`   Signing Algorithm: ${keyPairs.signing.algorithm}`);
    console.log(`   Encryption Algorithm: ${keyPairs.encryption.algorithm}\n`);

    // Step 2: Generate Domain Verification File
    console.log('🌐 Step 2: Generating domain verification file...');
    const verification = await domainVerification.generateVerificationFile(
      config.subscriberId,
      keyPairs.signing.privateKey
    );
    console.log('✅ Domain verification file generated');
    console.log(`   File URL: ${verification.url}`);
    console.log(`   Request ID: ${verification.requestId}\n`);

    // Step 3: Prepare Subscription Data
    console.log('📋 Step 3: Preparing subscription data...');
    const keyPairsForRegistration = await keyManager.getKeyPairsForRegistration(
      config.subscriberId,
      uniqueKeyId
    );

    const subscriptionData = registryService.createSubscriptionPayload({
      opsNo: 1, // Buyer App
      subscriberId: config.subscriberId,
      uniqueKeyId: uniqueKeyId,
      callbackUrl: '/ondc/callback',
      subscriberUrl: '/',
      keyPairs: keyPairsForRegistration,
      entityData: registryService.createEntityData(config.entityData),
      networkParticipants: config.networkParticipants.map(np => 
        registryService.createNetworkParticipantData(np)
      )
    });

    // Add private key for authorization header
    subscriptionData.privateKey = keyPairs.signing.privateKey;

    console.log('✅ Subscription data prepared');
    console.log(`   Operation: ${subscriptionData.context.operation.ops_no}`);
    console.log(`   Subscriber ID: ${subscriptionData.message.entity.subscriber_id}`);
    console.log(`   Network Participants: ${subscriptionData.message.network_participant.length}\n`);

    // Step 4: Subscribe to ONDC Registry
    console.log('🔗 Step 4: Subscribing to ONDC registry...');
    const subscriptionResult = await registryService.subscribe(
      subscriptionData,
      config.environment
    );

    if (subscriptionResult.success) {
      console.log('✅ Successfully subscribed to ONDC registry');
      console.log(`   Status: ${subscriptionResult.status}`);
      console.log(`   Response: ${JSON.stringify(subscriptionResult.data, null, 2)}\n`);
    } else {
      console.log('❌ Subscription failed');
      console.log(`   Error: ${JSON.stringify(subscriptionResult.error, null, 2)}\n`);
      return;
    }

    // Step 5: Verify Registration
    console.log('🔍 Step 5: Verifying registration...');
    const lookupResult = await registryService.lookup(
      {
        country: 'IND',
        domain: 'ONDC:RET10'
      },
      config.environment
    );

    if (lookupResult.success) {
      console.log('✅ Registration verified successfully');
      console.log(`   Found ${lookupResult.data.length || 0} participants in registry\n`);
    } else {
      console.log('⚠️  Could not verify registration');
      console.log(`   Error: ${JSON.stringify(lookupResult.error, null, 2)}\n`);
    }

    console.log('🎉 ONDC Network Participant Registration Complete!');
    console.log('\nNext Steps:');
    console.log('1. Ensure your domain is accessible with SSL certificate');
    console.log('2. Verify the ondc-site-verification.html file is accessible');
    console.log('3. Test your /ondc/callback/on_subscribe endpoint');
    console.log('4. Monitor the registry for your registration status');

  } catch (error) {
    console.error('❌ Registration failed:', error.message);
    console.error('Stack trace:', error.stack);
  }
}

// Run the complete registration
if (require.main === module) {
  completeRegistration();
}

module.exports = { completeRegistration, config };
