/**
 * ONDC API Usage Examples
 * 
 * This file contains examples of how to use the ONDC Network Participant API
 * for various operations.
 */

const axios = require('axios');

// API Base URL
const API_BASE_URL = 'http://localhost:3000';

// Helper function to make API calls
async function apiCall(method, endpoint, data = null) {
  try {
    const config = {
      method,
      url: `${API_BASE_URL}${endpoint}`,
      headers: {
        'Content-Type': 'application/json'
      }
    };

    if (data) {
      config.data = data;
    }

    const response = await axios(config);
    return response.data;
  } catch (error) {
    console.error(`API Error: ${error.message}`);
    if (error.response) {
      console.error(`Response: ${JSON.stringify(error.response.data, null, 2)}`);
    }
    throw error;
  }
}

// Example 1: Generate Key Pairs
async function generateKeyPairs() {
  console.log('🔑 Generating key pairs...');
  
  const result = await apiCall('POST', '/ondc/generate-keys', {
    subscriberId: 'tsp-seller.ondc.docboyz.in'
  });
  
  console.log('Key pairs generated:', result);
  return result.data;
}

// Example 2: Generate Domain Verification File
async function generateDomainVerification(subscriberId, uniqueKeyId) {
  console.log('🌐 Generating domain verification file...');
  
  const result = await apiCall('POST', '/ondc/generate-verification', {
    subscriberId,
    uniqueKeyId
  });
  
  console.log('Domain verification generated:', result);
  return result.data;
}

// Example 3: Subscribe to ONDC Registry
async function subscribeToRegistry(subscriberId, uniqueKeyId) {
  console.log('🔗 Subscribing to ONDC registry...');
  
  const subscriptionData = {
    opsNo: 2, // Seller App (as per your whitelisting role)
    subscriberId,
    uniqueKeyId,
    environment: 'staging',
    entityData: {
      legalEntityName: 'Novacred Private Limited',
      businessAddress: '123 Business Street, City, State, 123456',
      cityCodes: ['std:080'],
      gstNo: '27AAACN2082N1Z8',
      panName: 'Novacred Private Limited',
      panNo: 'AALCM8972B',
      dateOfIncorporation: '01/01/2020',
      authorisedSignatoryName: 'John Doe',
      authorisedSignatoryAddress: '123 Business Street, City, State, 123456',
      emailId: 'onenovacred@gmail.com',
      mobileNo: '9876543210',
      country: 'IND'
    },
    networkParticipants: [
      {
        type: 'sellerApp',
        msn: false,
        cityCodes: ['std:080'],
        subscriberUrl: '/',
        domain: 'nic2004:60232'  // Logistics domain as per whitelisting
      }
    ]
  };
  
  const result = await apiCall('POST', '/ondc/subscribe', subscriptionData);
  
  console.log('Subscription result:', result);
  return result;
}

// Example 4: Lookup Network Participants
async function lookupParticipants() {
  console.log('🔍 Looking up network participants...');
  
  const result = await apiCall('POST', '/ondc/lookup', {
    searchParams: {
      country: 'IND',
      domain: 'ONDC:RET10'
    },
    environment: 'staging'
  });
  
  console.log('Lookup result:', result);
  return result;
}

// Example 5: VLookup Network Participants (Deprecated)
async function vlookupParticipants() {
  console.log('🔍 VLooking up network participants...');
  
  const result = await apiCall('POST', '/ondc/vlookup', {
    searchParams: {
      sender_subscriber_id: 'example.com',
      request_id: 'test-request-id',
      timestamp: new Date().toISOString(),
      signature: 'test-signature',
      search_parameters: {
        country: 'IND',
        domain: 'ONDC:RET10'
      }
    },
    environment: 'staging'
  });
  
  console.log('VLookup result:', result);
  return result;
}

// Example 6: List Key Pairs
async function listKeyPairs() {
  console.log('📋 Listing key pairs...');
  
  const result = await apiCall('GET', '/ondc/keys');
  
  console.log('Key pairs:', result);
  return result;
}

// Example 7: Get System Status
async function getSystemStatus() {
  console.log('📊 Getting system status...');
  
  const result = await apiCall('GET', '/ondc/status');
  
  console.log('System status:', result);
  return result;
}

// Example 8: Health Check
async function healthCheck() {
  console.log('🏥 Checking health...');
  
  const result = await apiCall('GET', '/health');
  
  console.log('Health status:', result);
  return result;
}

// Example 9: Complete Registration Flow
async function completeRegistrationFlow() {
  try {
    console.log('🚀 Starting complete registration flow...\n');
    
    // Step 1: Generate keys
    const keyResult = await generateKeyPairs();
    const { uniqueKeyId } = keyResult;
    
    // Step 2: Generate domain verification
    await generateDomainVerification('example.com', uniqueKeyId);
    
    // Step 3: Subscribe to registry
    await subscribeToRegistry('example.com', uniqueKeyId);
    
    // Step 4: Verify with lookup
    await lookupParticipants();
    
    // Step 5: Check system status
    await getSystemStatus();
    
    console.log('\n✅ Complete registration flow finished!');
    
  } catch (error) {
    console.error('❌ Registration flow failed:', error.message);
  }
}

// Example 10: Different Registration Types
async function demonstrateRegistrationTypes() {
  console.log('📝 Demonstrating different registration types...\n');
  
  // Buyer App (ops_no: 1)
  console.log('1. Buyer App Registration:');
  const buyerAppData = {
    opsNo: 1,
    subscriberId: 'buyer.example.com',
    uniqueKeyId: 'buyer-key-id',
    environment: 'staging',
    entityData: {
      legalEntityName: 'Buyer Company',
      businessAddress: '123 Buyer Street',
      gstNo: '27AAACN2082N1Z8',
      panName: 'Buyer Company',
      panNo: 'AALCM8972B',
      dateOfIncorporation: '01/01/2020',
      authorisedSignatoryName: 'Buyer Signatory',
      authorisedSignatoryAddress: '123 Buyer Street',
      emailId: 'buyer@example.com',
      mobileNo: '9876543210'
    },
    networkParticipants: [{
      type: 'buyerApp',
      msn: false,
      cityCodes: ['std:080']
    }]
  };
  
  // Non-MSN Seller App (ops_no: 2)
  console.log('2. Non-MSN Seller App Registration:');
  const nonMsnSellerData = {
    opsNo: 2,
    subscriberId: 'seller.example.com',
    uniqueKeyId: 'seller-key-id',
    environment: 'staging',
    entityData: {
      legalEntityName: 'Seller Company',
      businessAddress: '456 Seller Street',
      gstNo: '27AAACN2082N1Z8',
      panName: 'Seller Company',
      panNo: 'AALCM8972B',
      dateOfIncorporation: '01/01/2020',
      authorisedSignatoryName: 'Seller Signatory',
      authorisedSignatoryAddress: '456 Seller Street',
      emailId: 'seller@example.com',
      mobileNo: '9876543210'
    },
    networkParticipants: [{
      type: 'sellerApp',
      msn: false,
      cityCodes: ['std:080']
    }]
  };
  
  // MSN Seller App (ops_no: 3)
  console.log('3. MSN Seller App Registration:');
  const msnSellerData = {
    opsNo: 3,
    subscriberId: 'msn-seller.example.com',
    uniqueKeyId: 'msn-seller-key-id',
    environment: 'staging',
    entityData: {
      legalEntityName: 'MSN Seller Company',
      businessAddress: '789 MSN Street',
      gstNo: '27AAACN2082N1Z8',
      panName: 'MSN Seller Company',
      panNo: 'AALCM8972B',
      dateOfIncorporation: '01/01/2020',
      authorisedSignatoryName: 'MSN Signatory',
      authorisedSignatoryAddress: '789 MSN Street',
      emailId: 'msn@example.com',
      mobileNo: '9876543210'
    },
    networkParticipants: [{
      type: 'sellerApp',
      msn: true,
      cityCodes: ['std:080'],
      sellerOnRecord: [{
        uniqueKeyId: 'seller-on-record-key-id',
        keyPair: {
          signingPublicKey: 'seller-signing-public-key',
          encryptionPublicKey: 'seller-encryption-public-key',
          validFrom: '2023-01-01T00:00:00.000Z',
          validUntil: '2024-01-01T00:00:00.000Z'
        },
        cityCodes: ['std:080']
      }]
    }]
  };
  
  console.log('Registration types demonstrated successfully!');
}

// Run examples
if (require.main === module) {
  (async () => {
    try {
      // Run individual examples
      await healthCheck();
      console.log('\n' + '='.repeat(50) + '\n');
      
      await completeRegistrationFlow();
      console.log('\n' + '='.repeat(50) + '\n');
      
      await demonstrateRegistrationTypes();
      
    } catch (error) {
      console.error('Example execution failed:', error.message);
    }
  })();
}

module.exports = {
  generateKeyPairs,
  generateDomainVerification,
  subscribeToRegistry,
  lookupParticipants,
  vlookupParticipants,
  listKeyPairs,
  getSystemStatus,
  healthCheck,
  completeRegistrationFlow,
  demonstrateRegistrationTypes
};
