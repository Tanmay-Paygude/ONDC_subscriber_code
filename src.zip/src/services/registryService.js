const axios = require('axios');
const cryptoUtils = require('../utils/crypto');
const logger = require('../utils/logger');
const config = require('../config/environment');

class RegistryService {
  constructor() {
    this.registryUrls = config.registry;
    this.ondcPublicKeys = config.ondcPublicKeys;
  }

  /**
   * Subscribe to ONDC Registry
   * @param {Object} subscriptionData - Subscription data
   * @param {string} environment - Environment (staging, preprod, prod)
   * @returns {Promise<Object>} Subscription response
   */
  async subscribe(subscriptionData, environment = 'staging') {
    try {
      logger.info(`Subscribing to ONDC registry (${environment})`);

      const registryUrl = this.getRegistryUrl(environment);
      const subscribeUrl = `${registryUrl}/ondc/subscribe`;

      // Create authorization header
      const requestBody = JSON.stringify(subscriptionData);
      const authHeader = await cryptoUtils.createAuthorizationHeader(
        requestBody,
        subscriptionData.message.entity.subscriber_id,
        subscriptionData.message.entity.unique_key_id,
        subscriptionData.privateKey
      );

      const response = await axios.post(subscribeUrl, subscriptionData, {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': authHeader
        },
        timeout: 30000
      });

      logger.info(`Successfully subscribed to ONDC registry (${environment})`);
      return {
        success: true,
        data: response.data,
        status: response.status
      };

    } catch (error) {
      logger.error(`Failed to subscribe to ONDC registry: ${error.message}`);
      
      if (error.response) {
        return {
          success: false,
          error: error.response.data,
          status: error.response.status
        };
      }
      
      throw error;
    }
  }

  /**
   * Handle on_subscribe callback from registry
   * @param {Object} challengeData - Challenge data from registry
   * @param {string} environment - Environment
   * @returns {Promise<Object>} Response to registry
   */
  async handleOnSubscribe(challengeData, environment = 'staging') {
    try {
      logger.info(`Handling on_subscribe callback for environment: ${environment}`);

      const { subscriber_id, challenge } = challengeData;
      
      // Get ONDC public key for the environment
      const ondcPublicKey = this.ondcPublicKeys[environment];
      if (!ondcPublicKey) {
        throw new Error(`ONDC public key not found for environment: ${environment}`);
      }

      // Load subscriber's encryption private key
      const keyManager = require('./keyManager');
      const keyPairs = await keyManager.loadKeyPairs(subscriber_id, 'default');
      
      // Generate shared secret
      const sharedSecret = cryptoUtils.generateSharedSecret(
        keyPairs.encryption.privateKey,
        ondcPublicKey
      );

      // Decrypt challenge
      const decryptedChallenge = cryptoUtils.decryptChallenge(challenge, sharedSecret);

      logger.info(`Successfully decrypted challenge for subscriber: ${subscriber_id}`);

      return {
        answer: decryptedChallenge
      };

    } catch (error) {
      logger.error(`Failed to handle on_subscribe: ${error.message}`);
      throw error;
    }
  }

  /**
   * Lookup network participants
   * @param {Object} searchParams - Search parameters
   * @param {string} environment - Environment
   * @returns {Promise<Object>} Lookup response
   */
  async lookup(searchParams, environment = 'staging') {
    try {
      logger.info(`Looking up network participants (${environment})`);

      const registryUrl = this.getRegistryUrl(environment);
      const lookupUrl = `${registryUrl}/v2.0/lookup`;

      const response = await axios.post(lookupUrl, searchParams, {
        headers: {
          'Content-Type': 'application/json'
        },
        timeout: 30000
      });

      logger.info(`Successfully looked up network participants (${environment})`);
      return {
        success: true,
        data: response.data,
        status: response.status
      };

    } catch (error) {
      logger.error(`Failed to lookup network participants: ${error.message}`);
      
      if (error.response) {
        return {
          success: false,
          error: error.response.data,
          status: error.response.status
        };
      }
      
      throw error;
    }
  }

  /**
   * VLookup network participants (deprecated)
   * @param {Object} searchParams - Search parameters
   * @param {string} environment - Environment
   * @returns {Promise<Object>} VLookup response
   */
  async vlookup(searchParams, environment = 'staging') {
    try {
      logger.info(`VLooking up network participants (${environment})`);

      const registryUrl = this.getRegistryUrl(environment);
      const vlookupUrl = `${registryUrl}/ondc/vlookup`;

      const response = await axios.post(vlookupUrl, searchParams, {
        headers: {
          'Content-Type': 'application/json'
        },
        timeout: 30000
      });

      logger.info(`Successfully vlooked up network participants (${environment})`);
      return {
        success: true,
        data: response.data,
        status: response.status
      };

    } catch (error) {
      logger.error(`Failed to vlookup network participants: ${error.message}`);
      
      if (error.response) {
        return {
          success: false,
          error: error.response.data,
          status: error.response.status
        };
      }
      
      throw error;
    }
  }

  /**
   * Get registry URL for environment
   * @param {string} environment - Environment
   * @returns {string} Registry URL
   */
  getRegistryUrl(environment) {
    const url = this.registryUrls[environment];
    if (!url) {
      throw new Error(`Invalid environment: ${environment}`);
    }
    return url;
  }

  /**
   * Create subscription payload for different operation types
   * @param {Object} params - Subscription parameters
   * @returns {Object} Subscription payload
   */
  createSubscriptionPayload(params) {
    const {
      opsNo,
      subscriberId,
      uniqueKeyId,
      callbackUrl,
      subscriberUrl,
      keyPairs,
      entityData,
      networkParticipants
    } = params;

    const basePayload = {
      context: {
        operation: {
          ops_no: opsNo
        }
      },
      message: {
        entity: {
          ...entityData,
          subscriber_id: subscriberId,
          unique_key_id: uniqueKeyId,
          callback_url: callbackUrl,
          key_pair: {
            signing_public_key: keyPairs.signing_public_key,
            encryption_public_key: keyPairs.encryption_public_key,
            valid_from: keyPairs.valid_from,
            valid_until: keyPairs.valid_until
          }
        },
        network_participant: networkParticipants,
        timestamp: new Date().toISOString(),
        request_id: cryptoUtils.generateRequestId()
      }
    };

    return basePayload;
  }

  /**
   * Create entity data for subscription
   * @param {Object} entityInfo - Entity information
   * @returns {Object} Entity data
   */
  createEntityData(entityInfo) {
    return {
      gst: {
        legal_entity_name: entityInfo.legalEntityName,
        business_address: entityInfo.businessAddress,
        city_code: entityInfo.cityCodes || ['std:080'],
        gst_no: entityInfo.gstNo
      },
      pan: {
        name_as_per_pan: entityInfo.panName,
        pan_no: entityInfo.panNo,
        date_of_incorporation: entityInfo.dateOfIncorporation
      },
      name_of_authorised_signatory: entityInfo.authorisedSignatoryName,
      address_of_authorised_signatory: entityInfo.authorisedSignatoryAddress,
      email_id: entityInfo.emailId,
      mobile_no: entityInfo.mobileNo,
      country: entityInfo.country || 'IND'
    };
  }

  /**
   * Create network participant data
   * @param {Object} participantInfo - Participant information
   * @returns {Object} Network participant data
   */
  createNetworkParticipantData(participantInfo) {
    const baseParticipant = {
      subscriber_url: participantInfo.subscriberUrl || '/',
      domain: participantInfo.domain || 'nic2004:52110',
      type: participantInfo.type,
      msn: participantInfo.msn || false,
      city_code: participantInfo.cityCodes || ['std:080']
    };

    // Add seller_on_record for MSN sellers
    if (participantInfo.type === 'sellerApp' && participantInfo.msn && participantInfo.sellerOnRecord) {
      baseParticipant.seller_on_record = [participantInfo.sellerOnRecord];
    }

    return baseParticipant;
  }

  /**
   * Validate subscription response
   * @param {Object} response - Subscription response
   * @returns {Object} Validation result
   */
  validateSubscriptionResponse(response) {
    const errors = [];

    try {
      if (!response.success) {
        errors.push('Subscription failed');
        if (response.error) {
          errors.push(`Error: ${JSON.stringify(response.error)}`);
        }
      }

      if (response.data && response.data.message) {
        const { ack, error } = response.data.message;
        
        if (ack && ack.status === 'NACK') {
          errors.push('Registry returned NACK');
        }
        
        if (error) {
          errors.push(`Registry error: ${error.message || 'Unknown error'}`);
        }
      }

      return {
        isValid: errors.length === 0,
        errors
      };

    } catch (error) {
      return {
        isValid: false,
        errors: [`Validation error: ${error.message}`]
      };
    }
  }
}

module.exports = new RegistryService();
