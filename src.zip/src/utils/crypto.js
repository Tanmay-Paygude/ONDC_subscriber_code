const crypto = require('crypto');
const nacl = require('tweetnacl');
const blake2b = require('blake2b-wasm');
const { v4: uuidv4 } = require('uuid');

class CryptoUtils {
  constructor() {
    this.algorithm = 'ed25519';
    this.hashAlgorithm = 'blake2b512';
  }

  /**
   * Generate Ed25519 signing key pair
   * @returns {Object} { publicKey, privateKey } in base64 format
   */
  generateSigningKeyPair() {
    try {
      const keyPair = crypto.generateKeyPairSync('ed25519');
      
      const publicKey = keyPair.publicKey.export({ type: 'spki', format: 'der' });
      const privateKey = keyPair.privateKey.export({ type: 'pkcs8', format: 'der' });
      
      return {
        publicKey: publicKey.toString('base64'),
        privateKey: privateKey.toString('base64'),
        algorithm: this.algorithm
      };
    } catch (error) {
      throw new Error(`Failed to generate signing key pair: ${error.message}`);
    }
  }

  /**
   * Generate X25519 encryption key pair
   * @returns {Object} { publicKey, privateKey } in base64 format
   */
  generateEncryptionKeyPair() {
    try {
      const keyPair = nacl.box.keyPair();
      
      // Convert to ASN.1 DER format for public key
      const publicKeyDer = this.convertX25519ToASN1(keyPair.publicKey);
      
      return {
        publicKey: publicKeyDer.toString('base64'),
        privateKey: Buffer.from(keyPair.secretKey).toString('base64'),
        algorithm: 'x25519'
      };
    } catch (error) {
      throw new Error(`Failed to generate encryption key pair: ${error.message}`);
    }
  }

  /**
   * Convert X25519 public key to ASN.1 DER format
   * @param {Uint8Array} publicKey - Raw X25519 public key
   * @returns {Buffer} ASN.1 DER encoded public key
   */
  convertX25519ToASN1(publicKey) {
    // ASN.1 DER encoding for X25519 public key
    const algorithmOID = Buffer.from([0x30, 0x2a, 0x30, 0x05, 0x06, 0x03, 0x2b, 0x65, 0x6e, 0x03, 0x21, 0x00]);
    const keyData = Buffer.from(publicKey);
    
    return Buffer.concat([algorithmOID, keyData]);
  }

  /**
   * Generate BLAKE-512 hash of data
   * @param {string|Buffer} data - Data to hash
   * @returns {Promise<string>} Base64 encoded hash
   */
  async generateBlake512Hash(data) {
    try {
      const dataBuffer = Buffer.isBuffer(data) ? data : Buffer.from(data, 'utf8');
      const hash = blake2b(64); // 512 bits = 64 bytes
      hash.update(dataBuffer);
      const digest = hash.digest();
      return digest.toString('base64');
    } catch (error) {
      throw new Error(`Failed to generate BLAKE-512 hash: ${error.message}`);
    }
  }

  /**
   * Sign data using Ed25519 private key
   * @param {string} data - Data to sign
   * @param {string} privateKeyBase64 - Private key in base64 format
   * @returns {string} Base64 encoded signature
   */
  signData(data, privateKeyBase64) {
    try {
      const privateKeyBuffer = Buffer.from(privateKeyBase64, 'base64');
      const privateKey = crypto.createPrivateKey({
        key: privateKeyBuffer,
        format: 'der',
        type: 'pkcs8'
      });
      
      const signature = crypto.sign(null, Buffer.from(data, 'utf8'), privateKey);
      return signature.toString('base64');
    } catch (error) {
      throw new Error(`Failed to sign data: ${error.message}`);
    }
  }

  /**
   * Verify Ed25519 signature
   * @param {string} data - Original data
   * @param {string} signature - Base64 encoded signature
   * @param {string} publicKeyBase64 - Public key in base64 format
   * @returns {boolean} True if signature is valid
   */
  verifySignature(data, signature, publicKeyBase64) {
    try {
      const publicKeyBuffer = Buffer.from(publicKeyBase64, 'base64');
      const publicKey = crypto.createPublicKey({
        key: publicKeyBuffer,
        format: 'der',
        type: 'spki'
      });
      
      const verifier = crypto.createVerify('ed25519');
      verifier.update(Buffer.from(data, 'utf8'));
      
      return verifier.verify(publicKey, Buffer.from(signature, 'base64'));
    } catch (error) {
      throw new Error(`Failed to verify signature: ${error.message}`);
    }
  }

  /**
   * Generate shared secret using X25519 key exchange
   * @param {string} privateKeyBase64 - Our private key in base64
   * @param {string} publicKeyBase64 - Counter party's public key in base64
   * @returns {Buffer} Shared secret
   */
  generateSharedSecret(privateKeyBase64, publicKeyBase64) {
    try {
      const privateKey = Buffer.from(privateKeyBase64, 'base64');
      const publicKey = Buffer.from(publicKeyBase64, 'base64');
      
      // Extract raw key from ASN.1 DER format
      const rawPublicKey = this.extractRawKeyFromASN1(publicKey);
      
      const sharedSecret = nacl.box.before(rawPublicKey, privateKey);
      return Buffer.from(sharedSecret);
    } catch (error) {
      throw new Error(`Failed to generate shared secret: ${error.message}`);
    }
  }

  /**
   * Extract raw key from ASN.1 DER format
   * @param {Buffer} asn1Key - ASN.1 DER encoded key
   * @returns {Uint8Array} Raw key bytes
   */
  extractRawKeyFromASN1(asn1Key) {
    // Skip ASN.1 header and extract raw key
    const keyStart = asn1Key.length - 32; // X25519 keys are 32 bytes
    return new Uint8Array(asn1Key.slice(keyStart));
  }

  /**
   * Decrypt challenge string using AES
   * @param {string} encryptedChallenge - Base64 encoded encrypted challenge
   * @param {Buffer} sharedSecret - Shared secret from key exchange
   * @returns {string} Decrypted challenge string
   */
  decryptChallenge(encryptedChallenge, sharedSecret) {
    try {
      const encryptedBuffer = Buffer.from(encryptedChallenge, 'base64');
      
      // Use first 32 bytes as key, next 16 bytes as IV
      const key = sharedSecret.slice(0, 32);
      const iv = encryptedBuffer.slice(0, 16);
      const encrypted = encryptedBuffer.slice(16);
      
      const decipher = crypto.createDecipheriv('aes-256-cbc', key, iv);
      let decrypted = decipher.update(encrypted, null, 'utf8');
      decrypted += decipher.final('utf8');
      
      return decrypted;
    } catch (error) {
      throw new Error(`Failed to decrypt challenge: ${error.message}`);
    }
  }

  /**
   * Generate unique request ID
   * @returns {string} UUID v4
   */
  generateRequestId() {
    return uuidv4();
  }

  /**
   * Generate unique key ID
   * @returns {string} UUID v4
   */
  generateUniqueKeyId() {
    return uuidv4();
  }

  /**
   * Create Authorization header for ONDC requests
   * @param {string} requestBody - JSON string of request body
   * @param {string} subscriberId - Subscriber ID
   * @param {string} uniqueKeyId - Unique key ID
   * @param {string} privateKeyBase64 - Private key in base64
   * @returns {Promise<string>} Authorization header value
   */
  async createAuthorizationHeader(requestBody, subscriberId, uniqueKeyId, privateKeyBase64) {
    try {
      // Generate digest using BLAKE-512
      const digest = await this.generateBlake512Hash(requestBody);
      
      // Generate timestamps
      const created = Math.floor(Date.now() / 1000);
      const expires = created + 3600; // 1 hour from now
      
      // Create signing string
      const signingString = `(created): ${created}\n(expires): ${expires}\ndigest:BLAKE-512=${digest}`;
      
      // Sign the string
      const signature = this.signData(signingString, privateKeyBase64);
      
      // Create Authorization header
      const keyId = `${subscriberId}|${uniqueKeyId}|${this.algorithm}`;
      const authHeader = `Signature keyId="${keyId}",algorithm="${this.algorithm}",created="${created}",expires="${expires}",headers="(created)(expires)digest",signature="${signature}"`;
      
      return authHeader;
    } catch (error) {
      throw new Error(`Failed to create authorization header: ${error.message}`);
    }
  }
}

module.exports = new CryptoUtils();
