const express = require('express');
const router = express.Router();
const cryptoUtils = require('../utils/crypto');
const keyManager = require('../services/keyManager');
const domainVerification = require('../services/domainVerification');
const registryService = require('../services/registryService');
const logger = require('../utils/logger');
const config = require('../config/environment');
const validationMiddleware = require('../middleware/validation');

/**
 * @route POST /ondc/generate-keys
 * @desc Generate key pairs for ONDC registration
 * @access Public
 */
router.post('/generate-keys', async (req, res) => {
  try {
    const { subscriberId } = req.body;

    const uniqueKeyId = cryptoUtils.generateUniqueKeyId();
    const keyPairs = await keyManager.generateKeyPairs(subscriberId, uniqueKeyId);

    res.json({
      success: true,
      data: {
        uniqueKeyId,
        keyPairs: {
          signing: {
            publicKey: keyPairs.signing.publicKey,
            algorithm: keyPairs.signing.algorithm
          },
          encryption: {
            publicKey: keyPairs.encryption.publicKey,
            algorithm: keyPairs.encryption.algorithm
          },
          metadata: keyPairs.metadata
        }
      }
    });

  } catch (error) {
    logger.error(`Failed to generate keys: ${error.message}`);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

/**
 * @route POST /ondc/generate-verification
 * @desc Generate domain verification file
 * @access Public
 */
router.post('/generate-verification', async (req, res) => {
  try {
    const { subscriberId, uniqueKeyId } = req.body;

    // Load key pairs
    const keyPairs = await keyManager.loadKeyPairs(subscriberId, uniqueKeyId);
    
    // Generate verification file
    const verification = await domainVerification.generateVerificationFile(
      subscriberId,
      keyPairs.signing.privateKey
    );

    res.json({
      success: true,
      data: verification
    });

  } catch (error) {
    logger.error(`Failed to generate verification file: ${error.message}`);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

/**
 * @route GET /ondc/verification
 * @desc Get domain verification file
 * @access Public
 */
router.get('/verification', async (req, res) => {
  try {
    const htmlContent = await domainVerification.getVerificationFileContent();
    res.setHeader('Content-Type', 'text/html');
    res.send(htmlContent);
  } catch (error) {
    logger.error(`Failed to get verification file: ${error.message}`);
    res.status(404).json({
      success: false,
      error: 'Verification file not found'
    });
  }
});

/**
 * @route POST /ondc/verification
 * @desc Get domain verification file content as JSON
 * @access Public
 */
router.post('/verification', async (req, res) => {
  try {
    const htmlContent = await domainVerification.getVerificationFileContent();
    
    res.json({
      success: true,
      message: 'Domain verification file content retrieved successfully',
      data: {
        content: htmlContent,
        contentType: 'text/html',
        subscriberId: config.subscriber.id,
        timestamp: new Date().toISOString(),
        url: `https://${config.subscriber.id}/ondc-site-verification.html`
      }
    });
  } catch (error) {
    logger.error(`Failed to get verification file via POST: ${error.message}`);
    res.status(404).json({
      success: false,
      error: 'Verification file not found'
    });
  }
});

/**
 * @route POST /ondc/subscribe
 * @desc Subscribe to ONDC registry
 * @access Public
 */
router.post('/subscribe', validationMiddleware.validateSubscribe, async (req, res) => {
  try {
    const {
      opsNo,
      subscriberId,
      uniqueKeyId,
      environment = 'staging',
      entityData,
      networkParticipants
    } = req.body;

    // Load key pairs
    const keyPairs = await keyManager.loadKeyPairs(subscriberId, uniqueKeyId);
    const keyPairsForRegistration = await keyManager.getKeyPairsForRegistration(subscriberId, uniqueKeyId);

    // Create subscription payload
    const subscriptionData = registryService.createSubscriptionPayload({
      opsNo,
      subscriberId,
      uniqueKeyId,
      callbackUrl: config.subscriber.callbackUrl,
      subscriberUrl: config.subscriber.subscriberUrl,
      keyPairs: keyPairsForRegistration,
      entityData: registryService.createEntityData(entityData),
      networkParticipants: networkParticipants.map(np => 
        registryService.createNetworkParticipantData(np)
      )
    });

    // Add private key for authorization header
    subscriptionData.privateKey = keyPairs.signing.privateKey;

    // Subscribe to registry
    const result = await registryService.subscribe(subscriptionData, environment);

    res.json({
      success: result.success,
      data: result.data,
      status: result.status
    });

  } catch (error) {
    logger.error(`Failed to subscribe: ${error.message}`);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

/**
 * @route POST /ondc/callback/on_subscribe
 * @desc Handle on_subscribe callback from registry
 * @access Public
 */
router.post('/callback/on_subscribe', validationMiddleware.validateOnSubscribe, async (req, res) => {
  try {
    const { subscriber_id, challenge } = req.body;
    const environment = req.headers['x-environment'] || 'staging';

    const result = await registryService.handleOnSubscribe(
      { subscriber_id, challenge },
      environment
    );

    res.json(result);

  } catch (error) {
    logger.error(`Failed to handle on_subscribe: ${error.message}`);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

/**
 * @route POST /ondc/lookup
 * @desc Lookup network participants
 * @access Public
 */
router.post('/lookup', validationMiddleware.validateLookup, async (req, res) => {
  try {
    const { searchParams, environment = 'staging' } = req.body;

    const result = await registryService.lookup(searchParams, environment);

    res.json({
      success: result.success,
      data: result.data,
      status: result.status
    });

  } catch (error) {
    logger.error(`Failed to lookup: ${error.message}`);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

/**
 * @route POST /ondc/vlookup
 * @desc VLookup network participants (deprecated)
 * @access Public
 */
router.post('/vlookup', validationMiddleware.validateVlookup, async (req, res) => {
  try {
    const { searchParams, environment = 'staging' } = req.body;

    const result = await registryService.vlookup(searchParams, environment);

    res.json({
      success: result.success,
      data: result.data,
      status: result.status
    });

  } catch (error) {
    logger.error(`Failed to vlookup: ${error.message}`);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

/**
 * @route GET /ondc/keys
 * @desc List all key pairs
 * @access Public
 */
router.get('/keys', async (req, res) => {
  try {
    const keyPairs = await keyManager.listKeyPairs();

    res.json({
      success: true,
      data: keyPairs
    });

  } catch (error) {
    logger.error(`Failed to list keys: ${error.message}`);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

/**
 * @route GET /ondc/keys/:subscriberId/:uniqueKeyId
 * @desc Get specific key pair
 * @access Public
 */
router.get('/keys/:subscriberId/:uniqueKeyId', validationMiddleware.validateKeyParams, async (req, res) => {
  try {
    const { subscriberId, uniqueKeyId } = req.params;

    const keyPairs = await keyManager.loadKeyPairs(subscriberId, uniqueKeyId);

    res.json({
      success: true,
      data: {
        signing: {
          publicKey: keyPairs.signing.publicKey,
          algorithm: keyPairs.signing.algorithm
        },
        encryption: {
          publicKey: keyPairs.encryption.publicKey,
          algorithm: keyPairs.encryption.algorithm
        },
        metadata: keyPairs.metadata
      }
    });

  } catch (error) {
    logger.error(`Failed to get keys: ${error.message}`);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

/**
 * @route DELETE /ondc/keys/:subscriberId/:uniqueKeyId
 * @desc Delete key pair
 * @access Public
 */
router.delete('/keys/:subscriberId/:uniqueKeyId', validationMiddleware.validateKeyParams, async (req, res) => {
  try {
    const { subscriberId, uniqueKeyId } = req.params;

    await keyManager.deleteKeyPairs(subscriberId, uniqueKeyId);

    res.json({
      success: true,
      message: 'Key pair deleted successfully'
    });

  } catch (error) {
    logger.error(`Failed to delete keys: ${error.message}`);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

/**
 * @route POST /ondc/test-body
 * @desc Test endpoint to verify body parsing
 * @access Public
 */
router.post('/test-body', async (req, res) => {
  try {
    res.json({
      success: true,
      message: 'Body parsing test',
      receivedBody: req.body,
      headers: req.headers
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

/**
 * @route GET /ondc/status
 * @desc Get system status
 * @access Public
 */
router.get('/status', async (req, res) => {
  try {
    const verificationExists = await domainVerification.verificationFileExists(config.subscriber.id);

    res.json({
      success: true,
      data: {
        subscriberId: config.subscriber.id,
        verificationFileExists: verificationExists,
        environment: config.nodeEnv,
        timestamp: new Date().toISOString()
      }
    });

  } catch (error) {
    logger.error(`Failed to get status: ${error.message}`);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

module.exports = router;
